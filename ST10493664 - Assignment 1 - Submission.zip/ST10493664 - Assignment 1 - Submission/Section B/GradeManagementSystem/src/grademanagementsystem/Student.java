package grademanagementsystem;
import java.util.Arrays;

//Subclass: Student inherits from Person
public class Student extends Person 
{
    private int[] marks;  //Array to store marks
    private String studentID;
    
    // Constructor
    public Student(String name, String studentID, int[] marks) 
    {
        super(name);  //Calling Person constructor
        this.studentID = studentID;
        this.marks = marks;
    }
    
    //Getter
    public String getStudentID() 
    {
        return studentID;
    }

    //Method to calculate average marks
    public double calculateAverage() 
    {
        int total = 0;
        for (int mark : marks) 
        {
            total += mark;  //loop to sum marks
        }
        return (double) total / marks.length;
    }
    
    //Method to find highest mark
    public int getHighestMark() 
    {
        int highest = marks[0];
        for (int mark : marks) 
        {
            if (mark > highest) 
            {
                highest = mark;
            }
        }
        return highest;
    }
    
    //Method to find lowest mark
    public int getLowestMark() 
    {
        int lowest = marks[0];
        for (int mark : marks) 
        {
            if (mark < lowest) 
            {
                lowest = mark;
            }
        }
        return lowest;
    }
    
    //Method to print a report
    public void printReport() 
    {
        System.out.println("\n===== Student Report =====");
        System.out.println("Name: " + getName());
        System.out.println("Student ID: " + studentID);
        System.out.println("Marks: " + Arrays.toString(marks));
        System.out.println("Average: " + calculateAverage());
        System.out.println("Highest Mark: " + getHighestMark());
        System.out.println("Lowest Mark: " + getLowestMark());
        System.out.println("==========================");
    }
}
