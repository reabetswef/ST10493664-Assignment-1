package grademanagementsystem;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StudentTest 
{
    @Test
    public void testCalculateAverage() 
    {
        //Arrange /Expected
        int[] marks = {80, 90, 100};
        
        //Act  /Actual
        Student student = new Student("Test", "T001", marks);
        
        //Assert
        assertEquals(90.0, student.calculateAverage(), 0.01);
    }
    
    @Test
    public void testHighestMark() 
    {
        //Arrange /Expected
        int[] marks = {55, 65, 75, 85};
        
        //Act  /Actual
        Student student = new Student("Test", "T002", marks);
        
        //Assert
        assertEquals(85, student.getHighestMark());
    }
    
    @Test
    public void testLowestMark() 
    {
        //Arrange /Expected
        int[] marks = {40, 60, 50, 70};
        
        //Act  /Actual
        Student student = new Student("Test", "T003", marks);
        
        //Assert
        assertEquals(40, student.getLowestMark());
    }
}

