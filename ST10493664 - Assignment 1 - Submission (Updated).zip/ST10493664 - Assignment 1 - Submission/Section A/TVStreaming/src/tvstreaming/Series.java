package tvstreaming;
import java.util.Scanner;

public class Series 
{
    //Declarations
    private String seriesId;
    private String seriesName;
    private int seriesAgeRes;
    private int seriesNumberOfEpisodes;
        
    //Constructors
    public Series()
    {
        
    }
    
    //Overloaded constructor
    public Series(String seriesId, String seriesName, int seriesAgeRes, int seriesNumberOfEpisodes) 
    {
        this.seriesId = seriesId;
        this.seriesName = seriesName;
        this.seriesAgeRes = seriesAgeRes;
        this.seriesNumberOfEpisodes = seriesNumberOfEpisodes;
    }
    
    //Mutators
    public void setSeriesId(String SeriesId) 
    {
        this.seriesId = SeriesId;
    }

    public void setSeriesName(String SeriesName) 
    {
        this.seriesName = SeriesName;
    }

    public void setSeriesAge(int SeriesAgeRes) 
    {
        this.seriesAgeRes = SeriesAgeRes;
    }

    public void setSeriesNumberOfEpisodes(int SeriesNumberOfEpisodes) 
    {
        this.seriesNumberOfEpisodes = SeriesNumberOfEpisodes;
    }

    //Accessors
    public String getSeriesId() 
    {
        return seriesId;
    }

    public String getSeriesName() 
    {
        return seriesName;
    }

    public int getSeriesAge() 
    {
        return seriesAgeRes;
    }

    public int getSeriesNumberOfEpisodes() 
    {
        return seriesNumberOfEpisodes;
    }    
    
    //Methods
    public static int captureSeries(Scanner input, Series[] seriesArray, int seriesCaptured) 
    {
        System.out.println("\nCAPTURE A NEW SERIES"
                + "\n-----------------------------------------------------------------------------------------");

        boolean idExists;
        String seriesId;
        String seriesName;
        int seriesAgeRes = 0;
        int seriesNumberOfEpisodes = 0;

        //Check for duplicate ID
        do 
        {
            System.out.println("Enter the series' id: ");
            seriesId = input.nextLine();

            idExists = false;
            for (Series series : seriesArray) 
            {
                if (series != null && series.getSeriesId().equals(seriesId)) 
                {
                    idExists = true;
                    System.out.println("Error: A series with the ID " + seriesId + " already exists."
                            + "\nPlease try again.\n");
                    break;
                }
            }
        } 
        while (idExists);

        System.out.println("\nEnter the series' name: ");
        seriesName = input.nextLine();
        
        
        //Validate age restriction
        System.out.println("\nEnter the series' age restriction: ");
        
        try
        {
            seriesAgeRes = Integer.parseInt(input.nextLine());
        }
        catch(Exception e)
        {
            System.out.println("Error: Invalid data input for age restriction!");
        }
        
        while (seriesAgeRes < 2 || seriesAgeRes > 18) 
        {
            System.out.println("Error: Invalid number for the age restriction!");
            System.out.println("\nRe-enter the series' age restriction: ");
            
            try
            {
                seriesAgeRes = Integer.parseInt(input.nextLine());
            }
            catch(Exception e)
            {
                System.out.println("Error: Invalid data input for age restriction!");     
            }
        }
        
        System.out.println("\nEnter the number of episodes: ");
        try
        {
            seriesNumberOfEpisodes = Integer.parseInt(input.nextLine());
        }
        catch(Exception e)
        {
            System.out.println("Error: Invalid data input for the number of episodes!");
        }
        
        while(seriesNumberOfEpisodes <= 0)
        {
            System.out.println("Error: Invalid number for the number of episodes!");
            System.out.println("\nRe-enter the number of episodes: ");
            
            try
            {
                seriesNumberOfEpisodes = Integer.parseInt(input.nextLine());
            }
            catch(Exception e)
            {
                System.out.println("Error: Invalid data input for the number of episodes!");
            }    
        }
        
        System.out.println("-----------------------------------------------------------------------------------------"
                + "\nSERIES PROCESSED SUCCESSFULLY!"
                + "\n-----------------------------------------------------------------------------------------");

        // Add to array
        seriesArray[seriesCaptured] = new Series(seriesId, seriesName, seriesAgeRes, seriesNumberOfEpisodes);
        seriesCaptured++;

        return seriesCaptured; //return updated count
    }
    
    
    //Search method
    public static String searchSeries(Series[] seriesArray, String seriesId) 
    {
        if (seriesArray == null) 
        {
            return "Error: No series array initialized.";
        }

        for (Series series : seriesArray) 
        {
            if (series != null && series.getSeriesId().equals(seriesId)) 
            {
                return series.toString();
            }
        }
        return "Series with ID: " + seriesId + " not found.";
    }

    //Update method
    public static boolean updateSeries(Series[] seriesArray, String seriesId, String newName, int newAgeRes, int newNumEpisodes) 
    {
        if (seriesArray == null) 
        {
            return false;
        }

        for (Series series : seriesArray) 
        {
            if (series != null && series.getSeriesId().equals(seriesId)) 
            {
                if (newAgeRes < 2 || newAgeRes > 18) 
                {
                    return false;
                }
                if (newNumEpisodes <= 0) 
                {
                    return false;
                }

                series.setSeriesName(newName);
                series.setSeriesAge(newAgeRes);
                series.setSeriesNumberOfEpisodes(newNumEpisodes);
                return true;
            }
        }
        return false;
    }
    
    //Delete method
    public static boolean deleteSeries(Series[] seriesArray, String seriesId) 
    {
        if (seriesArray == null) 
        {
            return false;
        }

        for (int i = 0; i < seriesArray.length; i++) 
        {
            if (seriesArray[i] != null && seriesArray[i].getSeriesId().equals(seriesId)) 
            {
                seriesArray[i] = null;
                return true;
            }
        }
        return false;
    }

    //Producing a report
    public static void seriesReport(Series[] seriesArray)
    {   
        //counter
        int count = 1;
        
        System.out.println("");
        boolean found = false;
        
        for(Series series: seriesArray)
        {
            if(series != null)
            {
                System.out.println("SERIES " + count
                        + "\n-----------------------------------------------------------------------------------------");
                System.out.println(series.toString() 
                        + "\n-----------------------------------------------------------------------------------------");
                found = true;
            }
            count++;
        }
        
        if(!found)
        {
            System.out.println("-----------------------------------------------------------------------------------------\n"
                    + "No series' have been captured yet."
                    + "\n-----------------------------------------------------------------------------------------");
        }
    }
    
    //Exiting the application
    public static void exitSeriesApplication() 
    {
        System.out.println("\n-----------------------------------------------------------------------------------------");
        System.out.println("Thank you for using the Series Application.");
        System.out.println("Goodbye!");
        System.out.println("-----------------------------------------------------------------------------------------");
        System.exit(0); //terminates the program
    }
    
    @Override
    public String toString() 
    {
        return "SERIES ID: " + seriesId 
                + "\nSERIES NAME: " + seriesName 
                + "\nSERIES AGE RESTRICTION: " + seriesAgeRes
                + "\nNUMBER OF EPISODES: " + seriesNumberOfEpisodes;
    }
}
