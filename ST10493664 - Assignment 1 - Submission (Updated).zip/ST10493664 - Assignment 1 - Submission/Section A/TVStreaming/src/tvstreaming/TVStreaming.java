package tvstreaming;
import java.util.Scanner;

public class TVStreaming 
{
    public static void main(String[] args) 
    {
        try
        {
            //Series class variable declaration
            String seriesId;
            String seriesName;
            int seriesAgeRes;
            int seriesNumberOfEpisodes;

            //Array declaration
            Series[] seriesArray = new Series[200];
            int seriesCaptured = 0;

            //Menu variables declaration
            int menuAnswer;
            int menuAnswer2;

            //Menu
            System.out.println("LATEST SERIES - 2025"
                    + "\n-----------------------------------------------------------------------------------------");

            //Menu Input Declaration
            Scanner input = new Scanner(System.in);

            System.out.println("Enter (1) to launch menu or any other key to exit.");
            menuAnswer = Integer.parseInt(input.nextLine());

            while (menuAnswer == 1) 
            {
                System.out.println("\nPlease select one of the following menu items: "
                        + "\n(1) Capture a new series"
                        + "\n(2) Search for a series"
                        + "\n(3) Update series"
                        + "\n(4) Delete a series"
                        + "\n(5) Print series report - 2025"
                        + "\n(6) Exit application");
                menuAnswer2 = Integer.parseInt(input.nextLine());

                //Capture a new series
                if (menuAnswer2 == 1) 
                {
                    seriesCaptured = Series.captureSeries(input, seriesArray, seriesCaptured);

                    System.out.println("Enter (1) to launch menu or any other key to exit.");
                    menuAnswer = Integer.parseInt(input.nextLine());
                } 

                //Search for a series
                else if (menuAnswer2 == 2) 
                {
                    System.out.println("\nEnter the series id to search: ");
                    String seriesIDSearch = input.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------");

                    String result = Series.searchSeries(seriesArray, seriesIDSearch);
                    System.out.println(result);
                    System.out.println("-----------------------------------------------------------------------------------------");

                    System.out.println("Enter (1) to launch menu or any other key to exit.");
                    menuAnswer = Integer.parseInt(input.nextLine());
                } 

                //Update series details
                else if (menuAnswer2 == 3) 
                {
                    System.out.println("\nEnter the series ID to update: ");
                    String updateId = input.nextLine();

                    System.out.println("Enter the new series name: ");
                    String newName = input.nextLine();

                    System.out.println("Enter the new age restriction: ");
                    int newAgeRes = Integer.parseInt(input.nextLine());

                    System.out.println("Enter the new number of episodes: ");
                    int newNumEpisodes = Integer.parseInt(input.nextLine());

                    boolean updated = Series.updateSeries(seriesArray, updateId, newName, newAgeRes, newNumEpisodes);

                    System.out.println("-----------------------------------------------------------------------------------------");
                    if (updated) 
                    {
                        System.out.println("Series with ID: " + updateId + " updated successfully.");
                    } 
                    else 
                    {
                        System.out.println("Update failed. Series not found or invalid details entered.");
                    }
                    System.out.println("-----------------------------------------------------------------------------------------");

                    System.out.println("Enter (1) to launch menu or any other key to exit.");
                    menuAnswer = Integer.parseInt(input.nextLine());
                }
                
                //Delete a series
                else if (menuAnswer2 == 4) 
                {
                    System.out.println("\nEnter the series ID to delete: ");
                    String seriesIDDelete = input.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------");

                    boolean deleted = Series.deleteSeries(seriesArray, seriesIDDelete);

                    if (deleted) 
                    {
                        System.out.println("Series with ID: " + seriesIDDelete + " deleted successfully.");
                    } else 
                    {
                        System.out.println("Series with ID: " + seriesIDDelete + " not found.");
                    }

                    System.out.println("-----------------------------------------------------------------------------------------");

                    System.out.println("Enter (1) to launch menu or any other key to exit.");
                    menuAnswer = Integer.parseInt(input.nextLine());
                } 

                //Print series report
                else if (menuAnswer2 == 5) 
                {
                    //Display all series
                    Series.seriesReport(seriesArray);

                    System.out.println("Enter (1) to launch menu or any other key to exit.");
                    menuAnswer = Integer.parseInt(input.nextLine());
                } 

                //Exit application
                else if (menuAnswer2 == 6) 
                {
                    Series.exitSeriesApplication();
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Invalid input!");
        }
    }
}
