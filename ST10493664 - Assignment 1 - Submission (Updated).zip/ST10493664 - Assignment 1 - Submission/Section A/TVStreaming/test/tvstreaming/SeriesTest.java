package tvstreaming;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class SeriesTest 
{
    private Series[] seriesArray;

    @Before
    public void setUp() 
    {
        seriesArray = new Series[2];
        seriesArray[0] = new Series("S001", "Breaking Code", 16, 10);
        seriesArray[1] = new Series("S002", "Java Hunters", 12, 8);
    }

    @Test
    public void TestSearchSeries() 
    {
        //Expected
        String expected = "SERIES ID: S001" +
                          "\nSERIES NAME: Breaking Code" +
                          "\nSERIES AGE RESTRICTION: 16" +
                          "\nNUMBER OF EPISODES: 10";
        
        //Actual
        String actResult = Series.searchSeries(seriesArray, "S001");
        
        //Assert
        assertEquals("Expected the exact series details but got:\n" + actResult,
                     expected, actResult);
    }

    @Test 
    public void TestSearchSeries_SeriesNotFound() 
    {
        //Arrange
        String expected = "Series with ID: S999 not found.";

        //Actual
        String actual = Series.searchSeries(seriesArray, "S999");

        //Assert
        assertEquals("Expected not-found message did not match.", expected, actual);
    }

    @Test
    public void TestUpdateSeries() 
    {
        //Arrange
        String seriesId = "S002";
        String newName = "Java Legends";
        int newAge = 15;
        int newEpisodes = 12;

        //Actual
        boolean updated = Series.updateSeries(seriesArray, seriesId, newName, newAge, newEpisodes);

        //Assert
        assertTrue("Update should return true for an existing series.", updated);
        assertEquals("Series name was not updated correctly.", newName, seriesArray[1].getSeriesName());
        assertEquals("Series age restriction was not updated correctly.", newAge, seriesArray[1].getSeriesAge());
        assertEquals("Series number of episodes was not updated correctly.", newEpisodes, seriesArray[1].getSeriesNumberOfEpisodes());
    }

    @Test
    public void TestDeleteSeries() 
    {
        //Arrange
        String seriesId = "S001";

        //Actual
        boolean deleted = Series.deleteSeries(seriesArray, seriesId);

        //Assert
        assertTrue("Delete should return true for an existing series.", deleted);
        assertNull("Series at index 0 should be null after deletion.", seriesArray[0]);
    }

    @Test
    public void TestDeleteSeries_SeriesNotFound() 
    {
        //Arrange
        String invalidSeriesId = "S888";

        //Actual
        boolean deleted = Series.deleteSeries(seriesArray, invalidSeriesId);

        //Assert
        assertFalse("Delete should return false when the series ID does not exist.", deleted);
    }


    @Test
    public void TestSeriesAgeRestriction_AgeValid() 
    {
        //Arrange
        String seriesId = "S001";
        int validAge = 18;
        int newEpisodes = 12;

        //Actual
        boolean updated = Series.updateSeries(seriesArray, seriesId, "Breaking Code", validAge, newEpisodes);

        //Assert
        assertTrue("Update should succeed with a valid age restriction (2–18).", updated);
        assertEquals("Series age restriction should be updated to 18.", validAge, seriesArray[0].getSeriesAge());
        assertEquals("Number of episodes should be updated to 12.", newEpisodes, seriesArray[0].getSeriesNumberOfEpisodes());
    }


    @Test
    public void TestSeriesAgeRestriction_SeriesAgeInValid() 
    {
        //Arrange
        String seriesId = "S002";
        int invalidAge = 25; // outside valid range 2–18
        int newEpisodes = 10;
        int originalAge = seriesArray[1].getSeriesAge();

        //Actual
        boolean updated = Series.updateSeries(seriesArray, seriesId, "Java Hunters", invalidAge, newEpisodes);

        //Assert
        assertFalse("Update should fail when age restriction is outside 2–18.", updated);
        assertEquals("Series age should remain unchanged when update fails.", originalAge, seriesArray[1].getSeriesAge());
        assertEquals("Number of episodes should remain unchanged when update fails.", seriesArray[1].getSeriesNumberOfEpisodes(), 8);
    }

    @Test
    public void TestSeriesNumEpisodesInvalid() 
    {
        //Arrange
        String seriesId = "S001";
        String seriesName = "Breaking Code";
        int validAge = 16;
        int invalidEpisodes = 0;
        int originalEpisodes = seriesArray[0].getSeriesNumberOfEpisodes();

        //Actual
        boolean updated = Series.updateSeries(seriesArray, seriesId, seriesName, validAge, invalidEpisodes);

        //Assert
        assertFalse("Update should fail when number of episodes is <= 0.", updated);
        assertEquals("Number of episodes should remain unchanged when update fails.", originalEpisodes, seriesArray[0].getSeriesNumberOfEpisodes());
    }
}
