package grademanagementsystem;
import java.util.Scanner;

public class GradeManagementSystem 
{
    public static void main(String[] args) 
    {
        try
        {
            //Declaration
            String name, studID;
            int numStudents;

            //Array for students (max 20)
            Student[] students = new Student[20];

            //User input
            Scanner input = new Scanner(System.in);

            System.out.print("How many students do you want to enter (max 20)? ");
            numStudents = Integer.parseInt(input.nextLine());

            for(int i = 0; i < numStudents; i++)
            {
                int[] marks2 = new int[5]; // array of 5 marks

                System.out.println("\n=== Enter details for Student " + (i+1) + " ===");

                System.out.print("Enter student name: ");
                name = input.nextLine();

                System.out.print("Enter student ID: ");
                studID = input.nextLine();

                //enter marks
                for (int j = 0; j < 5; j++)
                {
                    System.out.print("Enter mark " + (j+1) + ": ");
                    marks2[j] = Integer.parseInt(input.nextLine());
                }

                // create Student object and store in array
                students[i] = new Student(name, studID, marks2);
            }

            //printing reports
            for(int i = 0; i < numStudents; i++)
            {
                students[i].printReport();
            }
        }
        catch(Exception e)
        {
            System.out.println("Incorrect data type used.");
        }
    }
}
